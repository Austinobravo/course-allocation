## Project - A Course aloocation project


This web app is currently hosted on  [here](https://course-allocation-project.onrender.com/) 



## Technologies


 - NextJs
 - Tailwind CSS
 - Typescript


Happy viewing ✌.