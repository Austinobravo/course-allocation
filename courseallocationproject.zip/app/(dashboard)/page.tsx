import React from 'react'
import Navbar from './_components/Navbar'
import Sidebar from './_components/Sidebar'
import Courses from './_components/Courses'

const page = () => {
  return (
    <div>
        <Navbar/>
        <Courses/>
      
    </div>
  )
}

export default page
