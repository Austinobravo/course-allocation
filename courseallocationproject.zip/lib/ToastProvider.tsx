import React from 'react'
import { Toaster } from 'react-hot-toast'

const ToastProvider = () => {
  return (
    <div>
        <Toaster/>
      
    </div>
  )
}

export default ToastProvider
